# Whatsapp-UI Android 
  A perfect Whatsapp UI replica for developers ❤️ now available with dark theme
  
## ScreenShots

<img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/Whatsapp1.JPG"><img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/Whatsapp2.JPG" hspace=24/><img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/Whatsapp3.JPG"/> 

<br><br>

<img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/WD1.JPG"><img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/WD2.JPG" hspace=24/><img height=550 width=275 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/WD3.JPG"/> 

<br>

<img height=550 width=300 hspace=120 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/ProfileDialogWhite.gif"><img height=550 width=300 src="https://github.com/usman18/WhatsappUI-Android/blob/master/Screenshots/ProfileDialogDark.gif">


<br><br>

## Contributions
Contributions are always welcome. Please fork this repository and contribute using pull requests. The pull requests will be thoroughly assessed and if found significant will be accepted.


## Lets become friends
- [Medium](https://medium.com/@usman18)
- [Instagram](https://www.instagram.com/usman__khan18/)
- [Twitter](https://twitter.com/khan_usman_18)
- [LinkedIn](https://www.linkedin.com/in/usman-khan-7b04b1138)
- [Github](https://github.com/usman18)

My email : uk32971@gmail.com
